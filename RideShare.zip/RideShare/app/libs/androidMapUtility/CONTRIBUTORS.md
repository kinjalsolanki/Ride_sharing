<!-- Sorted alphabetically. -->

* Chris Broadfoot, https://github.com/broady
* Maciej Gorski, https://github.com/mg6maciej
* Cyril Mottier, https://github.com/cyrilmottier
* Mihai Preda, https://github.com/preda
